from pynncml.metrics.classification import accuracy
from pynncml.metrics.regression import mse, nmse