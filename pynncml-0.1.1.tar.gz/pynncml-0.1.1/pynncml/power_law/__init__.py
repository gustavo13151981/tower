from pynncml.power_law.pl_module import PowerLaw, PowerLawType
