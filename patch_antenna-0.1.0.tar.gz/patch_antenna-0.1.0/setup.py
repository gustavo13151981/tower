from os import path
from setuptools import setup


this_directory = path.abspath(path.dirname(__file__))
with open(path.join(this_directory, 'readme.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(name='patch_antenna',
      version='0.1.0',
      long_description=long_description,
      long_description_content_type='text/markdown',
      description='A simple patch antenna design library',
      url='https://github.com/bhanuchander210/patch_antenna.git',
      author='Bhanuchander Udhayakumar',
      author_email='bhanuchander210@gmail.com',
      license='MIT',
      packages=['patch_antenna'],
      include_package_data=True,
      zip_safe=False,
      install_requires=['scipy==1.9.0', 'gerber_writer==0.3.4']
      )
