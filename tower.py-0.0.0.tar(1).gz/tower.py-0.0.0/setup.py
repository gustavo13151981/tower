from __future__ import annotations

from setuptools import setup

setup(
    name="tower.py",
    version="0.0.0",
    author="Fabien Taxil",
    author_email="lixaft@gmail.com",
    url="https://github.com/lixaft/tower.py",
)
