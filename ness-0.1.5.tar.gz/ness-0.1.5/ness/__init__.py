from .datalake import DataLake as dl

__all__ = ["dl"]
__version__ = "0.1.5"
