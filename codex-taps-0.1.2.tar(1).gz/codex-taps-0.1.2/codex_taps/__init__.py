__version__ = "0.1.2"
__author__ = "Arpan Pandey"

key = "fJmGq_nX1SSPb_4OkNGRGaCrR5-oqZkMHomoX40Ai3A="
